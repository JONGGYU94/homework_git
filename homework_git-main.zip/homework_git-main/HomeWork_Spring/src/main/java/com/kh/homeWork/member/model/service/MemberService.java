package com.kh.homeWork.member.model.service;

import com.kh.homeWork.member.model.vo.Member;

public interface MemberService{

	Member loginCheck(Member m);

}
